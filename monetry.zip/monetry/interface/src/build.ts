declare var RELEASE: string;
declare var REVISION: string;
declare var NODE_VERSION: string;
