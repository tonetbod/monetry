import React from 'react';

import AllAccountsView from '@monetr/interface/components/BankAccounts/AllAccountsView/AllAccountsView';

export default function AccountsPage(): JSX.Element {
  return <AllAccountsView />;
}
