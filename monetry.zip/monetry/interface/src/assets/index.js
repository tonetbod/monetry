import Logo from './logo.svg';

// Dumb hack so I don't need to do weird stuff in typescript.
export { Logo };
