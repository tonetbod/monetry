//go:build icons
package icons

func init() {
	enabled = true
}
