# Icon Sources

When you are building monetr with icons included then sources for those icons will be put here.
