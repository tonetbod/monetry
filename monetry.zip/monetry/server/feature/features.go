package feature

type Feature string

const (
	FeatureManualBudgeting Feature = "ManualBudgeting"
	FeatureLinkedBudgeting Feature = "LinkedBudgeting"
)
