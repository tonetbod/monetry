package myownsanity

func BoolP(val bool) *bool {
	return &val
}
