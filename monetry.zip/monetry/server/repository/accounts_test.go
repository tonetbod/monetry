package repository_test

import (
	"context"
	"testing"

	"github.com/benbjohnson/clock"
	"github.com/monetr/monetr/server/internal/fixtures"
	"github.com/monetr/monetr/server/internal/testutils"
	"github.com/monetr/monetr/server/models"
	"github.com/monetr/monetr/server/repository"
	"github.com/stretchr/testify/assert"
)

func TestRepositoryBase_GetAccount(t *testing.T) {
	t.Run("account does not exist", func(t *testing.T) {
		clock := clock.NewMock()
		db := testutils.GetPgDatabase(t, testutils.IsolatedDatabase)

		repo := repository.NewRepositoryFromSession(clock, 123, 1234, db)
		account, err := repo.GetAccount(context.Background())
		assert.EqualError(t, err, "failed to retrieve account: pg: no rows in result set")
		assert.Nil(t, account, "should not return an account")
	})

	t.Run("account exists", func(t *testing.T) {
		clock := clock.NewMock()
		db := testutils.GetPgDatabase(t, testutils.IsolatedDatabase)

		user, _ := fixtures.GivenIHaveABasicAccount(t, clock)

		repo := repository.NewRepositoryFromSession(clock, user.UserId, user.AccountId, db)
		account, err := repo.GetAccount(context.Background())
		assert.NoError(t, err, "must not return an error if the account exists")
		assert.NotNil(t, account, "should return a valid account")
		assert.Equal(t, user.AccountId, account.AccountId, "retrieved account must match the fixture")
	})

	t.Run("will cache the account", func(t *testing.T) {
		clock := clock.NewMock()
		db := testutils.GetPgDatabase(t, testutils.IsolatedDatabase)

		user, _ := fixtures.GivenIHaveABasicAccount(t, clock)

		repo := repository.NewRepositoryFromSession(clock, user.UserId, user.AccountId, db)
		account, err := repo.GetAccount(context.Background())
		assert.NoError(t, err, "must not return an error if the account exists")
		assert.NotNil(t, account, "should return a valid account")
		assert.Equal(t, user.AccountId, account.AccountId, "retrieved account must match the fixture")

		// Then delete the account from the database.
		{
			result, err := db.ModelContext(context.Background(), &models.User{
				UserId:    user.UserId,
				AccountId: user.AccountId,
			}).
				WherePK().
				Delete()
			assert.NoError(t, err, "must successfully delete the account to test the cache")
			assert.Equal(t, 1, result.RowsAffected(), "should only delete the one account")

			result, err = db.ModelContext(context.Background(), &models.Account{AccountId: user.AccountId}).
				WherePK().
				Delete()
			assert.NoError(t, err, "must successfully delete the account to test the cache")
			assert.Equal(t, 1, result.RowsAffected(), "should only delete the one account")
		}

		// Calling get account again should still return the account as it is cached.
		account, err = repo.GetAccount(context.Background())
		assert.NoError(t, err, "must not return an error if the account exists")
		assert.NotNil(t, account, "should return a valid account")
		assert.Equal(t, user.AccountId, account.AccountId, "retrieved account must match the fixture")
	})
}
