# Security Policy

To report a security issue, please email security@monetr.app with a description of the issue, the steps you took to create the issue,
affected versions, and if known, mitigations for the issue. We will acknowledge receiving your email within 7 days. This project
follows a 90 day disclosure timeline.
