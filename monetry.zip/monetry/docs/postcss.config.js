/** @type {import('postcss').Postcss} */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
